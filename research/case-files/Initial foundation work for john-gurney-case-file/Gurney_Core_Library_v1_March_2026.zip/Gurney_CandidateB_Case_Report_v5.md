# Candidate B Case Report v5
**Project:** English identity of John Gurney of Braintree/Weymouth  
**Date:** 26 March 2026  
**Purpose:** Readable analytical report setting out the case that Candidate B is the strongest present identification, while clearly separating fact from hypothesis

## 1. Problem statement

John Gurney of Braintree/Weymouth, Massachusetts, is a documented seventeenth-century New England man. The unresolved question is which English John Gurney he was.

That question has proven difficult because the project is not dealing with one clean English candidate. It is dealing with a **conflation problem**. Multiple men named John Gurney, and multiple closely related spellings such as Gurnay, Gurny, Girney, and Gurley, appear in the relevant period. Some belong to Buckinghamshire lines, some to Hertfordshire lines, some to broader London or Norfolk settings, and some survive only in derivative genealogical traditions. Earlier genealogical writing has repeatedly blended pieces of these different men into one immigrant profile.

This report argues that **Candidate B** — the theory that the Massachusetts immigrant was an otherwise undocumented son of **Francis Gurney**, probably by **Margaret Rybett**, whom Francis married at Norwich in **1611** — is the strongest present explanation of the evidence assembled in the master library. It does **not** claim direct proof. The bridge record naming John as son of Francis has not yet been found. The argument is therefore cumulative and comparative rather than dispositive.

For source control, use `MSR`. For the fact ledger, use `MER`. For the side-by-side alternative analysis, use `MCC`.

## 2. Fixed baseline facts about the Massachusetts immigrant

Before turning to England, the immigrant profile itself has to be fixed as carefully as possible.

| Baseline fact | Working reading | MER anchors |
|---|---|---|
| **Massachusetts presence** | John was in the Weymouth/Braintree orbit by **June 1641**. | `E-001` |
| **Trade** | John Gurney was described as a **tailor**. | `E-002` |
| **Age statement** | In **1653** he was said to be **“about 50 years.”** | `E-003` |
| **Death window** | He was dead by **16 Mar 1662/63**. | `E-004` |
| **First wife** | His first wife was **Mary**, with no proved maiden surname. | `E-005` |
| **Children** | The compiled child sequence used in the library is **Sarah, Mary, Richard, John, Peter**, with **Isaac** possible but uncertain, and the early children are treated as England-born in the compiled reconstruction. | `E-007`–`E-019` |
| **Second wife** | Grizzell Fletcher belongs to John’s later colonial life and is not a valid English-origin clue. | `E-006` |

These points matter because an English candidate has to explain not just the name John Gurney, but the full Massachusetts profile: chronology, occupation, family structure, and the likely timing of migration.

## 3. The Candidate B theory

### 3.1 Summary of the theory

The central theory of this report is that immigrant tailor **John Gurney** of **Braintree, Massachusetts**, was **John Gurney**, the son of **Francis Gurney** of **West Barsham (Norfolk)** and **London** (**1581–1647**), a London tailor. Francis is securely placed in the **Norfolk–London** world: born into the Norfolk Gurney family, freed in the **Merchant Taylors’ Company** in **1606**, active in connection with **Norwich** and **Lynn**, and later visible in the **St Benet Fink** records from **1619** forward. John of Braintree appears in the right generation, in the right migration period, and in the same broad occupational sphere, as a tailor. The theory does not depend on any single marriage entry or any one discovery. It rests instead on cumulative fit: **chronology, trade, geography, family setting, and the unusual silences surrounding Francis’s early household, later life, and testamentary record**.

### 3.2 Narrative of the theory

**Francis Gurney** began life as a younger son of the old Gurney family of **West Barsham** in Norfolk, but his adult path was urban and commercial rather than manorial. Born in **1581**, he was sent to London, apprenticed in the **Merchant Taylors’** world, and admitted to freedom in **1606**. After that, the record becomes notably thin for more than a decade. Yet Francis did not disappear altogether: he remained connected to the **Norfolk–London corridor**, with ties to **Norwich**, **Lynn**, and the **Lestrange** circle, before the **St Benet Fink** household with **Anne Browning** comes clearly into view from **1619** onward. That interval matters because it is exactly where an earlier son could belong.

This is where **John of Braintree** enters the picture. He is of the right generation and appears in New England as a **tailor**, a detail that fits naturally with a father formed in the **Merchant Taylors’** trade. The point is not that the occupations are identical in a narrow guild sense, but that they lie in the same textile and clothing world, where training commonly moved through household and family channels. Geography also aligns unusually well. Francis’s known world ran through **Norfolk**, **Norwich**, **Lynn**, and **London**, which was also one of the principal corridors feeding migration to Massachusetts in the 1630s. The wider family setting strengthens the picture: **Francis’s brother Edmund** was a pronounced Protestant polemical figure, and the family moved in a milieu where religion, commerce, and kinship were tightly intertwined.

By the **1620s and 1630s**, Francis’s position appears to have weakened materially. The **Lynn** venture failed, debts followed, and in **1634** he sold off his remaining **Norfolk** and **Suffolk** lands. For a son with trade skills but little prospect of inheritance, emigration becomes a plausible life course rather than a strained hypothesis. The difficulties in the case are real—most notably the absence of a direct baptismal record and the **1633** reference to **Roger** as “eldest son and heir”—but they do not remove the larger pattern. Taken as a whole, the surviving evidence reads less like a random collection of coincidences than like a partially broken record of one family: **Francis in England, John in Massachusetts, and a missing link that has not yet been directly documented but remains more coherently explained here than under any competing theory**.

### 3.3 Why Candidate B remains the strongest present option

Candidate B remains the strongest present option not because every element is proved, but because it explains more of the established evidence with fewer special assumptions than any competing theory. **Candidate A** still has the best literal age fit to the **1653** statement “about 50 years,” and it therefore remains the strongest rival on chronology alone. But the Buckinghamshire material also shows a continuing local **John Gurney** line, with later baptisms and manor continuity that are difficult to reconcile with an emigrant already in Massachusetts by **1641**. **Candidate C** at **Berkhamsted** offers real child-name overlap, especially **Richard** and **Sarah**, but it lacks the richer occupational, kinship, and migration-corridor context that surrounds Francis. The **1615 / Newgate / Bury St Edmunds** tradition remains alive, but it still depends on a derivative tradition chain whose original record sequence has not yet been re-established.

What distinguishes Candidate B is the way separate classes of evidence converge. It is the only candidate that presently aligns the immigrant’s tailoring identity, a plausible paternal trade background, a confirmed first-marriage opening before the documented **Anne Browning** household, a Norfolk–London commercial setting, a family environment with both mercantile and Protestant reformist features, and a materially plausible motive structure after the collapse of Francis’s fortunes. Its weaknesses are real and should be stated plainly: there is still no direct father-son record, the reconstructed son set contains no **Francis**, the name **Peter** remains unexplained, and the age statement continues to pull toward an older John. Even so, the alternatives do not presently explain the whole profile better. For that reason, **Candidate B remains the strongest present identification, even while the case remains circumstantial rather than proved**.

## 4. The fact chain supporting Candidate B


### 4.1 Francis is a real and well-situated father candidate

| Fact | Why it matters | MER anchors |
|---|---|---|
| Francis belongs to the Norfolk Gurney line in the validated compiled tradition. | Gives Candidate B a real family context rather than a free-floating speculation. | `E-036` |
| Francis entered the Merchant Taylors’ world through apprenticeship and freedom in **1606**. | Provides the strongest occupational bridge to a Massachusetts tailor. | `E-037`–`E-039` |
| Francis was active in the Norwich / East Anglian commercial sphere by **1612**. | Places him in the right regional corridor for a later Massachusetts migrant family. | `E-040` |

### 4.2 The 1611 marriage solves the structural problem in Candidate B

| Fact | Why it matters | MER anchors |
|---|---|---|
| Francis married **Margaret Rybett** at Norwich on **23 Sep 1611**. | This is the pivotal fact that creates a real first-marriage family phase. | `E-041` |
| The first documented St Benet Fink Browning child is **Dorothy** in **1619**. | Creates a normal chronological space for earlier children by Margaret. | `E-042` |
| The St Benet Fink Browning child sequence runs **1619–1637**. | Confirms that the first-marriage child window sits before the later London family. | `E-043` |

Without the 1611 marriage, Candidate B required an invisible child somehow belonging to Francis outside the only known household. With the 1611 marriage fixed, Candidate B becomes a historically ordinary proposition: a first marriage, a first child phase, and then a later second family.

### 4.3 The first-marriage-child idea has more than one support point

| Fact | Why it matters | MER anchors |
|---|---|---|
| Susanna Gurnay’s will names **Thomas** as son of Francis. | Confirms at least one son outside the narrowest simplified retellings. | `E-047` |
| Ann Gurney married **John Gilman** in **1626**, remained in Norfolk, and belongs to a family with New England links. | Makes an earlier child set for Francis more plausible in social terms. | `E-048`–`E-052` |
| The Pease genealogy independently preserved the claim that Francis first married **Margaret Ryvett** and had **John** and **Anne** before Anne Browning. | The Pease claim is derivative, but part of it — the Margaret Ryvett marriage — is now independently confirmed. | `E-052` |
| A Boyd card / abstract preserves **Robert** as son of Francis, even though Daniel Gurney did not include him. | Weakens arguments built on the supposed completeness of Francis’s child list in Daniel Gurney. | `E-055` |

These points do not prove John. But they materially strengthen the proposition that Francis’s children were **not fully exhausted** by the better-known St Benet Fink series.

### 4.4 The religious and migration setting is directionally consistent

| Fact | Why it matters | MER anchors |
|---|---|---|
| Henry Gurney’s 1623 will includes a warning against sons holding **“fantasticall or erronious opinions.”** | Shows confessional concern inside Francis’s immediate family world. | `E-053` |
| Edmund Gurney, Francis’s brother, appears in preserved source material as a Protestant cleric and polemical figure. | Places Francis’s close kin in a recognizably reformist religious environment. | `E-054` |
| The preserved London Protestation Returns include other Gurneys in City parishes, including **St Stephen Coleman Street**. | Keeps the family in a City setting compatible with the broader reformist / migration corridor, though not as direct proof about John. | `E-059` |

This part of the case must be used carefully. These facts do **not** prove that John emigrated for religious reasons, and they do **not** identify him by name. What they do is remove some of the friction that would exist if Candidate B had to be placed in a family world with no confessional alignment at all.

### 4.5 The economic and chronological setting is historically coherent

| Fact | Why it matters | MER anchors |
|---|---|---|
| Francis sold Norfolk/Suffolk lands on **11 Jul 1634**. | Marks a major contraction in the family’s landed position. | `E-044` |
| The annuity claim of **3 Jul 1646** and probable burial of **9 Jan 1646/7** show a diminished late-life trajectory. | Supports a picture of household instability rather than secure succession. | `E-045`–`E-046` |
| The **1638** *Inhabitants of London* material shows no Gurney at St Benet Fink. | Suggests Francis and household movement out of that parish before the end of the decade. | `E-056` |

Taken together, these facts make the emigration of an adult son in the later 1630s historically plausible in a way that a settled local heir would not be.

## 5. The child evidence and why it matters

The child evidence is not proof by itself, but it is one of the best tests available because it forces every English candidate to match the structure of John’s household.

### 5.1 What the colonial child reconstruction gives us

| Point | Why it matters | MER anchors |
|---|---|---|
| The library uses a stable compiled child sequence: **Sarah, Mary, Richard, John, Peter**, with **Isaac** uncertain. | Gives the comparison process a consistent working household. | `E-007`–`E-017` |
| Several children are treated as **England-born** in the compiled reconstruction. | Requires an English family phase before Massachusetts. | `E-009`–`E-013` |
| No son named **Francis** appears in the reconstructed son set. | Creates a genuine naming-pattern objection to Candidate B. | `E-018` |
| The bounded England-wide search preserved **no Peter baptism** for 1620–1645. | Makes Peter a potentially decisive clue pointing toward Mary’s family. | `E-019` |

### 5.2 Why the child evidence does not displace Candidate B

The child evidence has often been used against Candidate B, and some of that criticism is fair. The absence of a son named **Francis** is a real difficulty. So is the still-unexplained name **Peter**. And no English baptism has yet been securely tied to the immigrant’s family in the bounded searches preserved in the source layer. See `E-018`, `E-019`, and `E-058`.

Even so, the competing English clusters do not solve the problem better:

| Cluster | What it offers | Why it does not outrank Candidate B | MER anchors |
|---|---|---|---|
| **Buckinghamshire / Aylesbury** | Mary 1631, John 1638, Sarah 1639, Jonathan 1647 around a father John | The same line also appears to continue locally in England. | `E-023`, `E-031`–`E-033`, `E-062`–`E-067` |
| **Berkhamsted** | Richard 1626, Sarah 1634, Francis 1637/39 around a father John | Good overlap, but much thinner trade and family context. | `E-020`–`E-022` |
| **Earsham** | John Girney 1636 | Worth preserving, but still only a single Norfolk father-John lead. | `E-024` |
| **South Mimms / St Giles** | Mary Gurnty 1630 and John Gurley / Mary Furrier 1626 | Useful preserved leads, but not enough to control the case. | `E-025`–`E-026` |

The child evidence therefore does not prove Candidate B. It simply fails to produce a rival candidate that is clearly stronger once all factors are weighed together.

## 6. Main objections to Candidate B

A credible case report has to state the main objections plainly.

| Objection | Why it matters | Present reading | MER anchors |
|---|---|---|---|
| **No direct father-son record** | This is the central missing bridge. | Conceded. The case remains circumstantial. | `E-058` |
| **The 1653 age statement fits a c.1603 birth better than a post-1611 birth.** | Keeps Candidate A alive as the strongest age-fit rival. | Conceded. Candidate B requires age approximation. | `E-003`, `E-060` |
| **No son named Francis appears in John’s reconstructed son set.** | A real naming-pattern problem if Francis is the father. | Conceded. | `E-018` |
| **Peter remains unexplained.** | Suggests the sharper clue may lie with Mary’s family, not Francis’s. | Conceded and preserved as a major future target. | `E-019` |
| **Other same-period Gurney / Gurley families existed in Norfolk and London.** | Prevents simplistic reasoning from surname or geography alone. | Conceded. | `E-034`, `E-059`, `E-072` |

These objections are why the conclusion must remain **most likely**, not **proved**.

## 7. Why Candidate B still leads over the alternatives

### Candidate A

Candidate A has the best age fit and should not be caricatured away. But the Buckinghamshire material preserves a father-John line that also looks locally continuous in England. That continuity is difficult to reconcile with the Massachusetts immigrant already being in New England by **1641**. See `E-023`, `E-031`–`E-033`, and `E-062`–`E-067`.

### Candidate C

Candidate C has respectable child-name overlap at Berkhamsted. But the library does not currently provide a comparable trade fit, migration-corridor fit, or richer family framework. See `E-020`–`E-022`.

### Candidate D

Candidate D remains active because the **1615** tradition still needs original-record recovery. But at present it is still a tradition cluster, not a fuller documented life. See `E-069`–`E-071`.

### Unknown other origin

Unknown origin must remain available because direct proof is missing. But the unknown bucket does not presently explain the evidence more coherently than Candidate B.

## 8. Working conclusion

The strongest current reading of the library is that John Gurney of Braintree/Weymouth was **most likely** an otherwise undocumented son of **Francis Gurney**, probably by Francis’s first wife **Margaret Rybett**, whom Francis married at **Norwich in 1611**.

That conclusion rests on the cumulative fit between:
- the immigrant’s tailoring identity,
- Francis’s Merchant Taylor background,
- the confirmed first marriage at Norwich,
- the resulting child window before the St Benet Fink Browning family,
- the broader Norfolk/London family and mercantile context,
- the indirect religion-context fit of Francis’s branch,
- and the fact that the principal alternatives each carry substantial weaknesses of their own.

The case remains unproved because the library still lacks the decisive bridge record. The proper present wording is therefore:

> **Candidate B is the strongest present identification, but the case remains circumstantial and should continue to be maintained alongside the full candidate comparison and fact ledger.**

## 9. Highest-yield future tests

| Research target | Why it would matter most | Related anchors |
|---|---|---|
| A baptism naming **John son of Francis** in the expected window | Would move the case from comparative likelihood toward proof | `E-041`–`E-043`, `E-058` |
| A burial for **Margaret Rybett** | Would tighten the chronology of the first-marriage-child phase | `E-041` |
| Francis’s will or administration | Could directly name children | `E-044`–`E-046` |
| A record linking John and **Mary** to the right child cluster in England | Could solve both migration timing and household structure | `E-005`, `E-007`–`E-019`, `E-025`–`E-026` |
| Evidence explaining **Peter** through Mary’s family | Could sharpen the immigrant’s English identity through the maternal line | `E-019` |
