# Gurney Anecdotes and Narrative Appendix v2
**Project:** Gurney genealogy in England  
**Date:** 24 March 2026  
**Purpose:** Preserve anecdotes, interpretive color, and narrative-ready details that are not themselves the core proof argument

---

## 1. How to use this appendix

This file is for:

- biography drafting,
- family narrative writing,
- preserving memorable source details,
- and storing material that may become useful later even if it does not drive the current proof argument.

For the actual identity case, use `CBR`, `MCC`, and `MER`.

---

## 2. Francis Gurney as a narrative figure

Francis is one of the strongest narrative figures in the project because his life sits at the meeting point of:

- county-gentry descent,
- London trade,
- Norwich and East Anglian commerce,
- and eventual financial decline.

That arc matters because it supplies a historically intelligible backdrop for why a son from such a household might end up in Massachusetts.

---

## 3. The younger son sent into trade

One of the most vivid surviving family details is Henry Gurney's observation that Francis at age sixteen was shorter than his twin Anthony and his voice had not yet changed. It is a small detail, but it makes Francis unusually human on the page.

Narratively, Francis can be presented as:

- a younger son who did not inherit the landed line,
- physically and personally distinct enough to leave an impression,
- and pushed into metropolitan and mercantile life rather than manor succession.

This detail is for color, not proof.

---

## 4. Francis in the Lestrange and Norwich world

The Lestrange material gives Francis social depth. He was not merely a name in a guild list. He appears in a real East Anglian financial and commercial world, moving between London, Norwich, and county society.

That matters narratively because it makes Candidate B's migration setting more concrete. If John came from Francis's household, he came from a family already accustomed to movement across regional and occupational boundaries.

---

## 5. The first-marriage chapter

The first-marriage phase with Margaret Rybett gives Francis's life a fuller emotional and narrative structure. His story no longer begins only with Anne Browning and the St Benet Fink children. It includes:

- an earlier Norwich marriage,
- a likely first household,
- probable children from that first marriage,
- and the possibility that later branch memory preserved that family only imperfectly.

For family narrative, this is one of the most valuable recoveries in the project.

---

## 6. Ann Gurney and the Gilman connection

If Ann Gurney of Hingham was Francis's daughter, then the first-marriage family did not simply disappear. It remained in the Norfolk textile world through the Gilmans and then touched New England indirectly through later migration.

Narratively, that supports a useful picture:

- one part of the family remained rooted in Norfolk,
- another part may have crossed the Atlantic,
- and both parts stayed linked to textile and East Anglian social worlds.

This should still be introduced with careful language such as **probably** or **most plausibly**.

---

## 7. Collapse, land sale, and emigration pressure

One of the strongest narrative frames in the project is that John, if he was Francis's son, did not leave a secure and expanding household. He left one marked by financial strain.

By the mid-1630s:

- Francis had sold his remaining landed interests,
- his business position had deteriorated,
- and the family appears less secure than the earlier pedigree alone would suggest.

That makes emigration by an adult son read less like random adventure and more like a rational family response to decline.

---

## 8. The children's names as a narrative clue

The child sequence is not just an analytical table. It is also narrative material.

Two features stand out:

- no son named **Francis**; and
- the startling presence of **Peter**, a name that appears to stand outside the normal Gurney naming field.

That combination suggests a more complicated family story than a simple grandfather-naming pattern. It also points toward **Mary**, John's first wife, as someone who may hold an equal share of the explanatory key.

A future family narrative should not let Francis overshadow Mary entirely.

---

## 9. Grizzell Fletcher as a correction, not an origin clue

The Grizzell Fletcher work is useful because it clears narrative clutter. Grizzell belongs to John's later colonial story. Her Chelmsford connection does not supply an English-origin path for him. She should therefore be treated as part of his Massachusetts life rather than as evidence about his English beginnings.

---

## 10. The cautionary tale of multiple Johns

The project's recurring warning is that later genealogical writing is very capable of compressing several same-name men into one neat pedigree.

That warning is itself narrative material. It explains why the case remains open and why family tradition, online trees, memorial pages, and even serious nineteenth-century compilations have to be handled critically.

This theme can be used in a future family narrative to explain why the English origin remained unsettled for so long.

---

## 11. Daniel Gurney: indispensable and fallible

Walter Rye's report that Daniel Gurney's relatives called his great work the “Apocryphal Book of Dan” is too memorable to lose. It should not be used to dismiss Daniel outright. The project still depends on Daniel heavily. But it is a perfect shorthand for the right methodological stance:

- Daniel preserved a huge amount of value;
- Daniel also made or repeated errors;
- and later work has to validate, not merely repeat him.

---

## 12. Supplemental preservation notes

The following items are preserved here so they do not disappear, even though they are not promoted into the main proof argument:

| Item | Narrative / archival treatment |
|---|---|
| **Find a Grave 29 Sep 1615 birth claim** | Preserve as a family-tradition style claim only, not as established biography |
| **St Ann, Blackfriars baptism to father “P Gurney”** | Preserve as a lead needing image review |
| **Anne Gurney 1619 at St Giles, father William** | Preserve as evidence that multiple same-period Norfolk Gurney families existed |
| **Purported image of John Gurney** | Preserve only if provenance can later be established |

---

## 13. Good material for future biography use

Especially usable items include:

- Francis as the younger son sent into trade;
- the physical description of Francis at age sixteen;
- Francis as a connector between Norfolk, Norwich, and London worlds;
- the first-marriage chapter with Margaret Rybett;
- the collapse-and-emigration frame;
- the role of Mary and the puzzle of Peter;
- and the broader theme of how multiple Johns became conflated in later memory.

---

## 14. Suggested one-paragraph family narrative summary

> Francis Gurney emerged from the Norfolk Gurney family not as a landed heir but as a younger son directed into the commercial world of London and Norwich. Freed as a Merchant Taylor in 1606, he moved through East Anglian mercantile networks, married first at Norwich in 1611, and later appears in London with the better-known Anne Browning family. His fortunes declined badly in the 1620s and 1630s, ending in the sale of lands and a far less secure household than the pedigree alone would suggest. If the current leading theory is correct, it was from this unsettled first-marriage family that John Gurney, later the tailor of Braintree, Massachusetts, emerged and crossed the Atlantic.

