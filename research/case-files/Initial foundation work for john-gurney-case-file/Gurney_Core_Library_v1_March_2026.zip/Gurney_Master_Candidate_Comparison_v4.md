# Gurney Master Candidate Comparison v4
**Project:** English identity of John Gurney of Braintree/Weymouth  
**Date:** 24 March 2026  
**Purpose:** Comparative analysis of the principal English candidates using the fact base in `MER` and the source layer in `MSR`

## 1. Problem statement

The problem is not simply to find an English man named John Gurney. Several men of that name, and several related spellings, appear in the relevant period. Some belong to local English family lines that seem to continue in place. Some appear only in derivative traditions. Some belong to broader London or Norfolk clusters that are easy to over-associate with the immigrant.

The real task is to determine which candidate best explains the **whole Massachusetts profile** without collapsing separate people into one life. That profile includes: Massachusetts presence by 1641, a tailoring identity, a wife named Mary, a compiled child sequence headed by England-born children, an age statement of “about 50” in 1653, and death by March 1662/63. See `MER E-001`–`E-019`.

## 2. Fixed baseline facts every candidate must explain

| Baseline fact | Why it matters | MER anchors |
|---|---|---|
| John was in the Weymouth/Braintree orbit by **June 1641**. | Rules out English lines that are securely still local afterward. | `E-001` |
| John is described as a **tailor**. | Makes occupational fit unusually important. | `E-002` |
| In **1653** he was said to be **“about 50 years.”** | Keeps age in play, but not as the only criterion. | `E-003` |
| Wife one is **Mary**; **Richards** is unproved. | Prevents overbuilding on a shaky maiden name. | `E-005` |
| The compiled child sequence is **Sarah, Mary, Richard, John, Peter**, with **Isaac** uncertain. | Creates a cross-check against English child clusters. | `E-007`–`E-019` |
| Several children are treated as **England-born** in the compiled reconstruction. | Requires an English family phase before Massachusetts. | `E-009`–`E-013` |

## 3. Candidate roster

| Candidate | Working label | Core description |
|---|---|---|
| **A** | Stewkley / Buckinghamshire | John son of John Gurney, baptized at Stewkley in 1602/3, or a closely related Bucks John line |
| **B** | Francis / Margaret | Otherwise undocumented son of Francis Gurney, probably by Margaret Rybett |
| **C** | Berkhamsted / Hertfordshire | Berkhamsted father-John line with child-name overlap |
| **D** | Bury St Edmunds / Newgate | The 1615 / apprentice / Newgate tradition cluster |
| **E** | Unknown other origin | A not-yet-identified English John outside the named candidates |

## 4. Comparative matrix

| Criterion | Candidate A | Candidate B | Candidate C | Candidate D | Key anchors |
|---|---|---|---|---|---|
| **Age fit to 1653 “about 50”** | Strong literal fit if using the 1602/3 Stewkley baptism | Weaker literal fit if John is born after the 1611 Francis–Margaret marriage | Unclear; no direct age anchor | Derivative 1615 tradition gives a partial age fit | `E-003`, `E-041`, `E-060`, `E-069`–`E-071` |
| **Trade fit to a Massachusetts tailor** | No tailoring fact in the library | Strongest trade context: Francis is repeatedly tied to Merchant Taylors and trade | No trade fit in the library | No tailor fit preserved; apprentice tradition remains underdefined | `E-002`, `E-037`–`E-040` |
| **Family-context coherence** | Clear local English family, but one that may continue in England | Strongest family context if the first-marriage-child theory is accepted as probable | Thin: child overlap exists, but larger family context is weak | Mostly derivative and under-recovered | `E-020`–`E-035`, `E-041`–`E-059`, `E-060`–`E-067` |
| **Child-sequence overlap** | Mary 1631, John 1638, Sarah 1639, Jonathan 1647 in the Bucks orbit | No direct English baptisms tied to the immigrant, but a plausible English family phase before 1641 | Richard 1626, Sarah 1634, Francis 1637/39 at Berkhamsted | No demonstrated child cluster | `E-007`–`E-019`, `E-020`–`E-035` |
| **Naming-pattern comfort** | Mixed | Hardest problem: no son Francis and unexplained Peter | Mixed | Unknown | `E-018`–`E-019` |
| **Local-English continuity after 1641** | Strong continuity signals in Bucks / Northants are a major difficulty | No equivalent continuity problem is yet demonstrated | Some Berkhamsted continuity exists, but the line is still thinner than A | Original-record chain not yet strong enough for continuity testing | `E-022`, `E-031`–`E-033`, `E-062`–`E-067` |
| **Indirect religion-context fit** | No positive factor currently documented in the library | Best documented fit: Henry’s 1623 will and Edmund Gurney’s Protestant clerical profile place Francis’s branch in a more relevant confessional environment, though only indirectly | No comparable factor documented | No comparable factor documented | `E-053`–`E-054`, `E-059` |
| **Direct parent-child proof** | None | None | None | None | `E-058`, `E-069` |
| **Overall standing in the baseline library** | Serious rival on age, but weakened by continuity issues | Leading cumulative explanation | Open but thinner | Active secondary alternative, not closed | whole register |

## 5. Candidate-by-candidate reading

### 5.1 Candidate A — Stewkley / Buckinghamshire

Candidate A’s strongest asset is straightforward: the Stewkley baptism in **1602/3** fits the **1653 “about 50”** statement better than the later-birth Candidate B model does. See `E-003`, `E-060`, and `E-061`.

The central problem is not the existence of the Stewkley John; it is the **continuity of a Bucks father-John line after the emigrant is already in Massachusetts**. The library preserves a Mary at Hitcham in **1631**, John and Sarah at Aylesbury in **1638** and **1639**, Jonathan at Aylesbury in **1647**, the **1642** Edlesborough and Cheddington tax entries, and the later **1687/1701** Stewkley manor continuity through John and Isaac son of John. See `E-023`, `E-031`–`E-033`, and `E-062`–`E-067`.

The most important caution inside Candidate A is the **John Sr. / John Jr.** ambiguity. The **1602/3** baptism proves two Johns in that line, which means later unqualified “John Gurney” records cannot automatically be assigned to the son. That keeps Candidate A open, but it also means Candidate A’s record set is not as clean as the age-fit first suggests. See `E-061`.

**Working comparison judgment:** Candidate A remains the strongest age-fit rival, but its local continuity evidence is a major analytical drag.

### 5.2 Candidate B — son of Francis Gurney and probably Margaret Rybett

Candidate B is the strongest cumulative explanation because it combines: a tailoring-family context, a Norfolk/London migration corridor, a confirmed first marriage in **1611**, room for an earlier child phase before the St Benet Fink Browning family, a plausible Norfolk Ann-Gilman sibling context, an indirect religion-context fit, and the absence of a demonstrated competing English life after the late 1630s. The core factual base is `E-036`–`E-059`.

The strongest points are not speculative by themselves. Francis is firmly tied to Merchant Taylors (`E-037`–`E-039`), East Anglian trade (`E-040`), the marriage to Margaret Rybett in **1611** (`E-041`), the Browning / St Benet Fink household from **1619** forward (`E-042`–`E-043`), the **1634** land sale (`E-044`), and late-life annuity / burial evidence (`E-045`–`E-046`). The Ann Gurney / John Gilman material makes an earlier child set more plausible, even if it does not prove John. See `E-048`–`E-052`.

The indirect religion-context factor is not proof of emigration motive, but it does belong in the comparison. The library preserves Henry Gurney’s 1623 anxiety about “fantasticall or erronious opinions,” Edmund Gurney’s Protestant clerical profile, and a broader London Gurney presence that reaches into the City’s more reformist environment. See `E-053`, `E-054`, and `E-059`.

The chief weakness is just as plain. The library still lacks a direct baptism or other record naming **John as son of Francis**, the age fit is less comfortable if John must be born after **23 Sep 1611**, and the naming pattern is awkward because the reconstructed sons do not include **Francis** while **Peter** remains unexplained. See `E-003`, `E-018`, `E-019`, and `E-058`.

**Working comparison judgment:** Candidate B remains the leading explanation because it explains more independent facts at once than any rival, even though it still lacks the bridge document.

### 5.3 Candidate C — Berkhamsted / Hertfordshire

Candidate C is real because it preserves a father-John line with **Richard 1626**, **Sara 1634**, and a further **Francis 1637 / burial 1639** cluster at Berkhamsted. This is more substance than many false leads ever produce. See `E-020`–`E-022`.

What Candidate C lacks is not a baptism; it lacks a larger explanatory framework. The library does not currently provide a trade fit, a strong migration-network fit, or a family context comparable to Francis’s. The Berkhamsted line therefore remains a live alternative, but a relatively thin one. The additional Hertfordshire contextual lead at Hitchin does little to change that. See `E-068`.

**Working comparison judgment:** Candidate C remains open, but it is presently a narrower and less coherent explanation than Candidate B.

### 5.4 Candidate D — Bury St Edmunds / Newgate / 1615 tradition

Candidate D remains in the file because the **1615** tradition cannot be dismissed merely because it is derivative. The library preserves both the BSE / Newgate apprentice path and two separate **1615**-type signals: the Find a Grave memorial date and the **St Ann, Blackfriars** baptism abstract with father **“P Gurney.”** See `E-069`–`E-071`.

At the same time, Candidate D remains under-recovered at the original-record level. The library does not yet contain a clean original-record chain showing who the apprentice was, how he connects to a specific family, or why he should be the Massachusetts tailor.

**Working comparison judgment:** Candidate D is a meaningful secondary alternative, not a discarded curiosity, but it is still less coherent than Candidate B on the present record set.

### 5.5 Candidate E — unknown other origin

Candidate E remains necessary because there is still **no direct proof** for any named candidate. The existence of multiple same-period Norfolk, London, Bucks, and Herts Gurney / Gurley / Girney families is exactly why an unidentified English John must remain on the table. See `E-034`, `E-035`, `E-072`, and `E-059`.

**Working comparison judgment:** Unknown-origin humility is still required, but the unknown bucket is not presently a better explanation than Candidate B.

## 6. The child evidence in comparative perspective

| Child-related point | Comparative reading | Anchors |
|---|---|---|
| The compiled Massachusetts sequence is stable enough for working use. | Good for comparison, but still compiled rather than directly documented at baptism. | `E-007`–`E-017` |
| No son named Francis appears. | A genuine difficulty for Candidate B. | `E-018` |
| No Peter baptism was preserved in the bounded England-wide search. | Makes Peter a clue that may point to Mary’s family rather than the paternal line. | `E-019` |
| Bucks preserves Mary / John / Sarah / Jonathan around a father John. | Strong overlap, but within a line that also seems to continue locally. | `E-023`, `E-031`–`E-033`, `E-062`–`E-067` |
| Berkhamsted preserves Richard / Sarah / Francis around a father John. | Useful overlap, but with much less wider context. | `E-020`–`E-022` |
| Norfolk controls show many other same-period Gurney families. | Reinforces anti-conflation caution. | `E-024`, `E-034`, `E-035` |

## 7. Bottom line

This is not a solved problem, but it is not a flat field either.

Candidate A remains the strongest literal age-fit rival. Candidate C remains a legitimate but thinner child-overlap alternative. Candidate D remains active because the 1615 tradition has not been fully re-opened at the original-record level. Candidate E must remain available because no direct proof exists.

Even so, Candidate B is still the best **cumulative** explanation in the baseline library. It is the only candidate that presently combines:
- a strong trade fit,
- a strong Norfolk/London corridor fit,
- a confirmed first marriage that creates the missing child window,
- a plausible sibling context through Ann Gurney / Gilman,
- an indirect religion-context fit,
- and a historically coherent family and economic setting for migration.

The proper present wording is therefore:

> **Candidate B remains the leading identification, but the case is still circumstantial and all principal alternatives must stay documented in the comparison file.**
