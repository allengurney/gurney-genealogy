# Gurney Master Research Library Guide v7
**Project:** Gurney genealogy in England, with focus on the English identity of John Gurney of Braintree/Weymouth, Massachusetts  
**Prepared for:** Allen Lawrence Gurney  
**Date:** 24 March 2026  
**Status:** Baseline master library for ongoing project maintenance

## 1. Purpose

This guide defines the **master research library** for the Gurney project.

The goal is to replace a scattered body of iterative notes with a smaller, durable set of working artifacts that can be maintained over time without losing earlier reasoning, discarded leads, or useful side findings. The prior project files remain the **source archive**. The master set is the **working library**.

This baseline is designed to do two things at once:

1. present the argument in a way a non-specialist reader can follow; and  
2. preserve enough analytical detail that future revisions do not accidentally lose earlier work, especially on children, naming patterns, anti-conflation evidence, religious-context evidence, and secondary candidates.

## 2. Problem statement

The core problem is not simply finding an English-born John Gurney of the right era. The real problem is that **multiple different men named John Gurney appear in English and colonial materials, and later genealogical writing has repeatedly blended them together**.

The immigrant John Gurney of Braintree/Weymouth is real and documented in Massachusetts. What is not yet directly documented is his English place of origin and parentage. Over time, several different English identities have been attached to him, including a Buckinghamshire John, a Hertfordshire John, a Newgate/Bury St Edmunds apprentice, and a John connected to Francis Gurney of the Norfolk/London family. Some of those identifications rely on original records; others rely on derivative compilations, memorial pages, or repeated online tradition.

The project therefore has two linked tasks:

- determine which English candidate best fits the Massachusetts man; and  
- keep separate the records that belong to different Johns so that later researchers do not silently recombine them.

That is why the master library preserves **all major candidates**, not only the current leading one.

## 2.1 Published genealogy and conflation pattern

Some commonly repeated published genealogy and descendant material lean toward a **Candidate A–type** or **1603 / 1615** framework and, in practice, sometimes blend that material with evidence now used in the **Candidate B** theory. In other words, one repeated danger in this project is not just choosing the wrong candidate, but **silently combining pieces from multiple candidates into one synthetic immigrant life**.

The main strands that must be kept separate are:

- the **Stewkley / Buckinghamshire** line with a baptized John in **1602/3** and later continuity material;
- the **1615** tradition cluster, including the Newgate / Bury St Edmunds apprentice path, Find a Grave date claims, and the unresolved **St Ann, Blackfriars** baptism;
- and the **Francis / Margaret / Norwich** theory built around the confirmed **1611** marriage and the later St Benet Fink household.

The library therefore treats published genealogy as useful only after it is decomposed back into those source strands. See `MER E-060`–`E-067`, `E-069`–`E-072`, and `MLR` section 2.

## 3. Current working conclusion

The present working conclusion of the baseline library is:

> **Candidate B remains the strongest current identification** for John Gurney of Braintree/Weymouth, but the case is still circumstantial and not yet proved by a direct father-son record.

Candidate B is the theory that the Massachusetts immigrant was an otherwise undocumented son of **Francis Gurney**, Merchant Taylor of the Norfolk/London Gurney family, probably by Francis's first wife **Margaret Rybett**, married at Norwich in 1611.

That conclusion rests mainly on seven linked points:

1. Francis's first marriage to Margaret Rybett at Norwich in 1611 forms part of the baseline evidence set.
2. That marriage creates a credible birth window for an undocumented son John after 1611 and before the documented Browning family at St Benet Fink.
3. Francis is a documented **Merchant Taylor**, while the Massachusetts John is a **tailor**.
4. Francis's documented world runs through **Norfolk, Norwich, London, Lynn, textile, and migration-corridor networks**, which fits the migration setting better than the Buckinghamshire candidate.
5. Francis's financial contraction and sale of lands provide a plausible context for an adult son to emigrate.
6. Francis's branch also has an **indirect religion-context fit** through Henry Gurney's 1623 will and Edmund Gurney's clerical / Protestant profile, which is not proof but does align directionally with a Massachusetts migration setting.
7. The best competing candidates each explain only part of the pattern and carry their own significant contradictions.

At the same time, the library treats the following as unresolved and material:

- no direct record names John as Francis's son;
- the 1653 age statement still fits a c.1603 man more easily than a post-1611 birth;
- John's children's names do not clearly support Francis as father;
- and the 1615/Newgate tradition still has to be kept alive as a live alternative rather than dismissed.

See `MER`, `MCC`, and `CBR` for the detailed balance.

## 4. Master artifact set

| Code | File | Function | Primary audience |
|---|---|---|---|
| **MLG** | `Gurney_Master_Library_Guide_v7.md` | Orientation, conventions, coverage map, artifact map | Anyone entering the project |
| **MLR** | `Gurney_Master_Library_Rules_v4.md` | Technical rules, source-control rules, fact-vs.-analysis discipline, update conventions | Researchers and AI maintainers |
| **MSR** | `Gurney_Master_Source_Register_v8.md` | Source control, source descriptions, lead handling, legacy intake map | Researchers maintaining the library |
| **MER** | `Gurney_Master_Evidence_Register_v8.md` | Fact-first evidence ledger | Researchers and analysts |
| **MCC** | `Gurney_Master_Candidate_Comparison_v4.md` | Side-by-side comparison of all principal candidates | Researchers and informed readers |
| **CBR** | `Gurney_CandidateB_Case_Report_v4.md` | Readable case report for Candidate B | General readers and family audience |
| **ANA** | `Gurney_Anecdotes_and_Narrative_Appendix_v2.md` | Narrative-ready material, side details, and preservation items | Future biography or family-history drafting |

## 5. Operating model

Detailed operating rules live in `Gurney_Master_Library_Rules_v4.md`.

The working model is now explicit:

- `MSR` = source layer  
- `MER` = fact layer  
- `MCC` / `CBR` = analysis layer  

This separation is intended to prevent future updates from silently turning hypotheses into facts.

## 6. Candidate roster

| Code | Short description | Current standing |
|---|---|---|
| **A** | Stewkley / Buckinghamshire John | Open, but materially weakened by continuity evidence |
| **B** | Son of Francis Gurney, probably by Margaret Rybett | Strongest current case |
| **C** | Berkhamsted / Hertfordshire John | Open, but thinner than A or B |
| **D** | Bury St Edmunds / Newgate-linked apprentice | Active secondary alternative |
| **E** | Unknown or not-yet-identified English John | Must remain open pending direct proof |

## 7. Normalized baseline facts

| Subject | Baseline statement |
|---|---|
| **Massachusetts John's death** | John Gurney died by **16 March 1662/63**, the inventory date. |
| **Francis's death window** | Francis was still alive for the annuity evidence of 1646 and is identified in project work with burial at **St Botolph Bishopsgate, 9 January 1646/7**. |
| **Candidate B birth implication** | If Candidate B is correct, John's birth should fall after the **1611** Francis–Margaret marriage and before the documented Browning sequence at St Benet Fink beginning in **1619**. |
| **Status of direct proof** | No direct parent-child record naming both Francis and John has yet been surfaced. |
| **Status of the 1615/Newgate tradition** | Still a live alternative, but not accepted as controlling. |
| **Status of Mary** | John's first wife is **Mary**, maiden surname unknown; **Richards** remains unproved. |
| **Status of Grizzell Fletcher** | Grizzell belongs to John's colonial life and provides no clean English-origin clue. |
| **Status of Peter** | Peter remains the strongest naming anomaly and may point to Mary's family rather than the Gurneys. |
| **Status of religion-context evidence** | The library preserves religious-context facts for Francis's branch, but treats them as indirect fit only, not as proof of John's personal motive. |

## 8. Coverage audit: where the uploaded source files now live

| Uploaded source file | Main content | Where it is represented in the master set |
|---|---|---|
| `Session4_Summary.docx` | Session 4 rollup, priorities, probability framing | `MSR`, `MER`, `MCC`, `CBR` |
| `Gurney_Genealogy_Chat_Session4_Summary_Focus_on_John_and_Francis_Gurney.docx` | Session 4 rollup variant | `MSR`, `MER`, `MCC`, `CBR` |
| `Gurney_Genealogy_Chat_Session4_Summary_Focus_on_John_and_Francis_Gurney_Evidence_Inventory.docx` | Evidence inventory variant | `MSR`, `MER`, `CBR` |
| `Gurney_Session4_Summary_Evidence_Inventory.docx` | Evidence inventory variant | `MSR`, `MER`, `CBR` |
| `Gurney_Research_Findings_V7.md` | Integrated synthesis for Candidate B baseline | `MSR`, `MER`, `MCC`, `CBR`, `ANA` |
| `Gurney_CandidateB_CaseFile_V2.md` | Candidate B theory and evidence chain | `MSR`, `MER`, `MCC`, `CBR` |
| `John_Gurney_Children_Matrix_V3.md` | Children / naming / parish-search matrix | `MSR`, `MER`, `MCC`, `CBR`, `ANA` |
| `Gurney_Children_ReValidation_V1.docx` | Chronology reset, reopened and eliminated child leads | `MSR`, `MER`, `MCC`, `CBR` |
| `Gurney_DG_Validation_CandidateA_Update_Mar2026.md` | Candidate A weakening evidence; Daniel validation | `MSR`, `MER`, `MCC`, `ANA` |
| `Daniel_Gurney_Book_Research _Validation_Mar2026.md` | Daniel validation parallel synthesis | `MSR`, `MER`, `MCC`, `ANA` |
| `Daniel_Gurney_Book_Research _Validation_Initial_Mar2026.md` | Initial Daniel validation notes | `MSR`, `MER`, `ANA` |
| `Gurney_DanielGurney_Validation_Findings.md` | Page-by-page Daniel validation findings | `MSR`, `MER`, `MCC`, `CBR`, `ANA` |
| `Gurney_Sources_Citations_V3.md` | Source and citation control | `MSR`, `MER` |
| `Gurney_John_Initial_Research_Comparion--SUPERCEDED.docx` | Earlier comparison structure | `MSR`, `MCC`, `CBR` |
| `Gurney_PrimarySource_Anecdotes.docx` | Narrative material and interpretive color | `MSR`, `MER`, `ANA` |
| `Francis_Maldon_Norwich_Focused_Packet.txt` | Francis/Maldon/Norwich narrative framing | `MSR`, `MER`, `ANA` |
| `Gurney_ProtestationReturns_Analysis.md` | London/Puritan context and anti-Bucks context | `MSR`, `MER`, `MCC`, `ANA` |
| `Independent-research-report-has-not-been-validated.md` | External memo, not controlling | `MSR`, `MER` as caution only |
| `Gurney_AncestorTable_V3_WithLandHoldings.docx` | Broad lineage and landholding background | background context only |
| `map_approach.md` | Cartographic working note | project support note |
| **Supplemental items supplied in chat** | Find a Grave 1615 entry; Blackfriars baptism transcript; Anne 1619 William baptism; image question | `MSR`, `MER`, `ANA` |

## 9. Update workflow

When the library is updated:

1. update `MSR` first if a source or lead changes status;
2. update `MER` second so all factual claims anchor to `SR` records;
3. update `MCC` and `CBR` third so interpretive claims reflect the revised fact base;
4. keep narrative-only or biography-ready material in `ANA`;
5. keep the project files as source archive, not working citation layer.

## 10. Decisive records still sought

The records that would most strongly change the state of the case are:

- a baptism explicitly naming **John** as son of **Francis Gurney**;
- a will or administration for **Francis Gurney** naming children;
- a burial for **Margaret Rybett** that tightens the chronology of the first marriage;
- a clean English record linking **John and Mary** to a candidate child cluster;
- and better original-record recovery for the **1615 / Newgate / Bury St Edmunds** path.

Until one of those appears, the library's proper posture is **strong preference for Candidate B, but not proof**.
