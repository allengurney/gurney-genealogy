# Gurney Master Library Rules v4
**Project:** Gurney genealogy in England  
**Date:** 24 March 2026  
**Purpose:** Operating rules for maintaining the stand-alone Gurney master research library

## 1. Library architecture

The master library is organized into distinct layers:

| File | Function |
|---|---|
| `Gurney_Master_Library_Guide` | Orientation for new users, including library map and update guidance. |
| `Gurney_Master_Library_Rules` | Operating rules, evidence discipline, naming conventions, and maintenance checks. |
| `Gurney_Master_Source_Register` (`MSR`) | Authoritative source-record layer. Every evidentiary anchor must resolve to an `SR-###` entry here. |
| `Gurney_Master_Evidence_Register` (`MER`) | Fact-first evidence ledger. Every row should be a source-derived fact, a compiled-source fact, a bounded search-result fact, a library-state fact, or an anti-conflation control. |
| `Gurney_Master_Candidate_Comparison` (`MCC`) | Comparative reasoning layer. Competing candidates are evaluated here against the fact base. |
| `Gurney_CandidateB_Case_Report` (`CBR`) | Narrative argument layer for the present leading theory, written for both non-specialists and expert readers. |
| `Gurney_Anecdotes_and_Narrative_Appendix` (`ANA`) | Narrative-grade details and preserved side material not central to proof. |

## 2. Source-control rules

1. **MSR is the only citation authority inside the master library.**  
   `MER`, `MCC`, and `CBR` should point to `SR-###` records, not to legacy project files.

2. **Legacy uploaded files are intake material, not citation endpoints.**  
   `PF-###` entries may remain in `MSR` only as an assimilation map.

3. **Each `SR-###` entry should describe one source record or one tightly bounded source cluster.**  
   Avoid mixing unrelated items in one `SR` unless they form a true source cluster used together for one factual purpose.

4. **Citation detail should be concrete.**  
   Include repository, collection, parish, film, volume, page, memorial number, record reference, and similar locator detail whenever available.

5. **URL cells should contain only actual links.**  
   If no meaningful URL is available, leave the field blank.

6. **Reliability should reflect source character, not desired outcome.**  
   Use low levels for derivative pedigrees, memorial pages, unresolved abstracts, or unvalidated memos even when they preserve useful leads.

7. **Published genealogy must be decomposed into source strands before it drives conclusions.**  
   A compiled genealogy may preserve useful clues, but it must not be allowed to blend Candidate A, Candidate B, the 1615 tradition, and unrelated London / Norfolk controls into one synthetic life.

## 3. Fact-layer rules for MER

1. **MER rows must be fact-first.**  
   A row should state what a source says, what a compiled source reconstructs, what a bounded project search preserved, or what the current library state does and does not contain.

2. **MER is not the place for candidate argument.**  
   Do **not** write “this proves Candidate B,” “this weakens Candidate A,” or similar as the main statement text. Interpretive effect may appear briefly in the relevance column, but the statement itself must stay factual.

3. **Compiled reconstructions must be labeled as such.**  
   Acceptable form: “The compiled colonial sources used in the library reconstruct John’s child set as …”  
   Unacceptable form: “John definitely had …” when no direct record proves the point.

4. **Library-state facts must be labeled as library-state facts.**  
   Acceptable form: “The current master library does not yet contain a baptism naming John son of Francis.”  
   Unacceptable form: “No such baptism exists.”

5. **Bounded negative-search claims must state their limits.**  
   Include the geography, date range, surname variants if known, and the fact that search / transcription / survival limits remain.

6. **Keep anti-conflation evidence.**  
   Controls showing other same-period Gurney families, spelling variants, or unrelated John families are positive value and should be preserved.

7. **Principal anchors must be human-readable.**  
   Use a short source title followed by `SR-###`.

8. **Do not treat lack of evidence as a positive fact unless the boundary is explicit.**  
   Missing parish coverage, lost registers, transcription error, surname drift, and search incompleteness must always remain visible.

## 4. Analysis-layer rules for MCC and CBR

1. **MCC and CBR are the hypothesis layers.**  
   They may compare, weigh, and infer from `MER`, but they should cite the relevant `MER` and `SR` anchors plainly.

2. **Separate “fact” from “what the fact suggests.”**  
   Example:  
   - `MER`: “Jonathan Gurney was baptized at Aylesbury St Mary on 22 Nov 1647 to father John.”  
   - `MCC/CBR`: “That record supports the view that a Bucks father-John line remained in England.”

3. **Probability language belongs only in analysis files.**  
   Do not put percentage ranges or candidate rankings inside `MER`.

4. **State objections in the same discipline as supporting points.**  
   If a theory requires accepting age approximation, naming-pattern difficulty, or missing direct proof, say so directly.

5. **Indirect religion-context factors belong in analysis, not motive claims in the fact layer.**  
   `MER` may preserve the raw religious facts. `MCC` and `CBR` may explain why those facts make one candidate more directionally compatible with a Massachusetts migration setting. They must not turn those facts into a claimed motive without direct evidence.

## 5. Baseline language rules

1. Avoid time-relative phrases such as **recent**, **newly found**, **currently newly found**, or similar.  
   Treat the library as a baseline corpus as of its stated date.

2. Prefer precise dates over vague periods whenever available.

3. Preserve uncertainty explicitly with phrases such as:  
   - **established**  
   - **probable**  
   - **working reconstruction**  
   - **preserved derivative claim**  
   - **unresolved lead**  
   - **bounded search-result fact**  
   - **library-state fact**

4. Do not overstate compiled genealogies or memorial pages as primary evidence.

## 6. Normalization rules

1. Preserve original spelling in citation detail where relevant, but normalize names in short titles when useful.  
   Examples: `Gurney`, `Gurnay`, `Girney`, `Gurny`, `Gurley`, `Gouerne`.

2. Use dual-year notation for English dates that fall in the pre-1752 new-year crossover when helpful, e.g. **1662/63**.

3. When a source is derivative but preserves a valuable claim, keep it in `MSR` with an honest reliability level rather than discarding it.

## 7. Maintenance workflow

1. Re-read key source materials page by page when keyword search risks omission, especially child matrices, evidence inventories, chronology-reset files, and candidate-comparison drafts.  
2. Create or revise `SR` entries first.  
3. Then update `MER` so every evidence row anchors only to `SR` entries.  
4. Then update `MCC` and `CBR` to reflect the revised fact base.  
5. Preserve superseded ideas in analysis files rather than deleting them without trace, unless they were pure error.

## 8. Validation checks

Before publishing a revision:

- every `SR-###` cited in `MER` exists in `MSR`
- `MER` contains no `PF-###` references
- `MER` rows that state search failures clearly describe the search boundary
- `MSR` citation detail does not point back to project files as if they were sources
- URLs are blank where no real link exists
- record-level facts and hypotheses are not merged in the same `MER` row
- `MCC` and `CBR` do not present their interpretations as though they were direct source quotations
- where religion or ideology appears, the file distinguishes between **documented context** and **claimed personal motive**

## 9. Standing cautions for this project

- Multiple **John Gurney** candidates and multiple unrelated **Gurney / Gurnay / Girney / Gurley** families exist in the relevant period.
- Parish survival, indexing coverage, and transcription accuracy are incomplete.
- Daniel Gurney’s work is valuable but must remain cross-checked.
- Common published genealogy and online descendant material may silently conflate Candidate A, Candidate B, and the 1615 tradition.
- The absence of a located record is not the same thing as proof that no record existed.
- The goal is a transportable, update-friendly research library that later AI or human operators can extend without re-fragmenting the project.
