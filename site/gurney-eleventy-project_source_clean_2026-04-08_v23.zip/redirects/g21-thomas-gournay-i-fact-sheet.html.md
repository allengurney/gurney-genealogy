---
layout: false
permalink: /g21-thomas-gournay-i-fact-sheet.html
---
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta http-equiv="refresh" content="0; url=/fact-sheets/g21-thomas-gournay-i-fact-sheet.html"><link rel="canonical" href="/fact-sheets/g21-thomas-gournay-i-fact-sheet.html"><title>Redirecting…</title><script>location.replace('/fact-sheets/g21-thomas-gournay-i-fact-sheet.html');</script></head><body><p>Redirecting to <a href="/fact-sheets/g21-thomas-gournay-i-fact-sheet.html">/fact-sheets/g21-thomas-gournay-i-fact-sheet.html</a>.</p></body></html>
