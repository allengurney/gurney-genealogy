---
layout: layouts/base.njk
permalink: /fact-sheets/g31-walter-de-gournay-fact-sheet.html
title: Walter de Gournay Fact Sheet
pageHeading: Walter de Gournay (fl. c. 1108–1154)
subtitle: "Ancestor fact sheet for G31 in the direct Gurney line. Junction point: youngest son of Gerard de Gournay; ancestor of all English and American Gurneys. Published April 2026."
description: "Compact fact sheet for Walter de Gournay in the direct Gurney line."
bodyClass: bio-page factsheet-page
activeNav: factsheets
updated: 2 April 2026
factsheet:
  gen: G31
  slug: g31-walter-de-gournay-fact-sheet
  personName: Walter de Gournay
  heroImage: /media/factsheets/g31-walter-de-gournay-hero.png
  heroAlt: Harpley Church, Norfolk — the manor that would define the family for the next two centuries
  heroCaption: St. Lawrence Church, Harpley, Norfolk — the manor church of the Gournay junior branch that Walter's descendants would hold for nearly two centuries.
  heroCredit: Geograph / CC BY-SA.
---

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "ProfilePage",
  "name": "Walter de Gournay — Fact Sheet",
  "description": "Compact fact sheet for Walter de Gournay in the direct Gurney line.",
  "mainEntity": {
    "@type": "Person",
    "name": "Walter de Gournay",
    "birthDate": "c. 1108",
    "birthPlace": { "@type": "Place", "name": "Normandy or England" },
    "description": "Youngest son of Gerard de Gournay. Ancestor of the entire Norfolk junior branch of the Gournay family."
  }
}
</script>

<div class="factsheet-top">
  <div class="factsheet-main">

<section class="fact-section fact-section-vitals" id="vital-records">
<div class="facts-vitals-grid">
  <div class="fact-item">
    <div class="fact-label">Born</div>
    <div class="fact-value">c. 1108, probably England or Normandy. Youngest son of Gerard de Gournay (G32) and Edith de Warenne. <sup class="fn"><a href="#n1" id="ref-1">1</a></sup></div>
  </div>
  <div class="fact-item">
    <div class="fact-label">Died</div>
    <div class="fact-value">Dates uncertain. Active during the reign of King Stephen (1135–1154). Son William I living 1167, suggesting Walter died c. 1150–1165. <sup class="fn"><a href="#n2" id="ref-2">2</a></sup></div>
  </div>
  <div class="fact-item">
    <div class="fact-label">Occupation / Status</div>
    <div class="fact-value">Lord of manors in Norfolk and Suffolk. Mesne tenant under the senior Lords of Gournay and under Manasser de Dampmartin in Suffolk. <sup class="fn"><a href="#n3" id="ref-3">3</a></sup></div>
  </div>
  <div class="fact-item">
    <div class="fact-label">Buried</div>
    <div class="fact-value">Unknown. No record. <sup class="fn"><a href="#n2" id="ref-2b">2</a></sup></div>
  </div>
  <div class="fact-item fact-item-span-2">
    <div class="fact-label">Marriage(s)</div>
    <div class="fact-value">
      <div class="stacked-records">
        <div><strong>Unknown.</strong> No wife named in DG or any other source consulted. <sup class="fn"><a href="#n4" id="ref-4">4</a></sup></div>
      </div>
    </div>
  </div>
</div>
</section>

<section class="fact-panel fact-panel-highlights" id="highlights">
<h2 class="unnumbered">Highlights</h2>

<ul>
  <li><strong>THE junction point — all English Gurneys descend from this man.</strong> Walter was the youngest son of Gerard de Gournay (Crusader, d. in Palestine). His elder brother Hugh IV inherited the great Norman fief of Gournay-en-Bray and the senior barony. Walter received a younger son's portion — manors in Norfolk and Suffolk — and from him descend every subsequent English Gurney: the medieval Norfolk gentry, the West Barsham Gurneys, the 18th-century banking Gurneys, and through Francis Gurney's probable son John Gurney-1, the American Gurneys including Allen Lawrence Gurney. <sup class="fn"><a href="#n5" id="ref-5">5</a></sup></li>
  <li><strong>Lived through one of England's most chaotic periods.</strong> Walter's active years coincide with "The Anarchy" — the civil war between King Stephen and Empress Matilda (1135–1153) that reduced much of England to lawlessness. Daniel Gurney notes specifically that "he lived during the civil wars in the reign of Stephen." The Norfolk gentry managed to survive this period with their estates intact. <sup class="fn"><a href="#n6" id="ref-6">6</a></sup></li>
  <li><strong>His son William held land in parage in Normandy — proof of blood descent from the Barons of Gournay.</strong> William de Gournay I (G30) held the lordship of Montigny-sur-Andelle in the Pays de Bray in parage — a tenure granted only to blood relatives of the senior lord. This constitutes, as Daniel Gurney stated, "incontestable proof of descent in blood from the Barons of Gournay" — confirming that Walter was indeed who DG said he was: a son of Gerard. <sup class="fn"><a href="#n7" id="ref-7">7</a></sup></li>
</ul>
</section>


<section class="fact-section" id="children">
<h2 class="unnumbered">Children</h2>

<table class="facts-children">
  <thead>
    <tr>
      <th>Name</th>
      <th>Dates</th>
      <th>Mother</th>
      <th>Notes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>William de Gournay I</td>
      <td>fl. c. 1150–1180</td>
      <td>Unknown</td>
      <td>G30 in direct line. Knight ("Dominus Willelmus"). Lord of Runhall; held Montigny-sur-Andelle in Normandy in parage. Living 1167. <sup class="fn"><a href="#n8" id="ref-8">8</a></sup></td>
    </tr>
  </tbody>
</table>
</section>

<section class="fact-section fact-narrative" id="narrative">
<h2 class="unnumbered">Narrative</h2>

Walter de Gournay occupies a peculiar position in this family history. He is, genealogically, one of the most important ancestors in the entire line — the single person through whom every English and American Gurney descends — and yet he is also one of the least documented. A single sentence in the Liber Niger Scaccarii, the Black Book of the Exchequer compiled c. 1166, establishes that he held lands in Suffolk under Manasser de Dampmartin. Daniel Gurney's identification of him as the youngest son of Gerard de Gournay (G32) and Edith de Warenne rests on the pedigree's internal logic, the geographical pattern of the estates, and — most critically — the Montigny-sur-Andelle tenure that his son William inherited, which could only have been granted to a blood relative of the senior Gournay lords.

Walter appears to have received his portion of the family's English holdings as a younger son's share when his father Gerard died in Palestine before 1104. The estates he held — Runhall and Swathings in Hardingham, Norfolk, and lands in Suffolk — were part of the Norfolk and Suffolk manors that had come into the Gournay family through Gerard's marriage to Edith de Warenne. Under the Norman custom of the period, a younger son could hold a portion of the fief "in parage" — at equal tenure with his elder brother — and this is precisely the tenure William de Gournay I held for Montigny-sur-Andelle.

Walter lived his adult years during "The Anarchy," Stephen's reign (1135–1154), when the breakdown of royal authority left many English lords navigating a dangerous landscape of shifting loyalties and local violence. He navigated it quietly — there is no record of Walter himself in any political or military event, which was probably the wisest course for a minor Norfolk landlord.

He is classified as **Confirmed** on the basis of the Liber Niger Scaccarii entry (an Exchequer document of the highest reliability) and the pedigree logic confirmed by his son's Montigny-sur-Andelle tenure.
</section>

<section class="fact-section" id="citations">
<h2 class="unnumbered">Citations</h2>

<ol class="citation-list">
  <li id="n1">Daniel Gurney, <em>Record</em> (1848), p. 286 (Norfolk pedigree): "WALTER DE GOURNAY, held lands in Suffolk, under Manasser de Dampmartin, in the reign of Stephen (Liber Niger Scaccarii, vol. i. p. 298), probably son of Gerard de Gournay and Editha Warren." <a class="citation-back" href="#ref-1">↩</a></li>
  <li id="n2">No death date in any source. Son William I living 1167 (Daniel Gurney, <em>Record</em> (1848), p. 278); active generation therefore c. 1108–c. 1155. <a class="citation-back" href="#ref-2">↩</a></li>
  <li id="n3">Daniel Gurney, <em>Record</em> (1848), p. 278: Walter "was lord of the manor of Runhall and Swathings in Norfolk." Liber Niger Scaccarii, vol. i, p. 298 (Suffolk tenure under Manasser de Dampmartin). <a class="citation-back" href="#ref-3">↩</a></li>
  <li id="n4">No wife named in DG or any other source consulted. <a class="citation-back" href="#ref-4">↩</a></li>
  <li id="n5">Daniel Gurney, <em>Record</em> (1848), p. 277: "WALTER DE GOURNAY, youngest son of Gerard and Editha, ancestor of this line." Daniel Gurney, <em>Record</em> (1848), p. 286 (pedigree). The junior Norfolk branch subsequently traced through Harpley, West Barsham, London, and Massachusetts. <a class="citation-back" href="#ref-5">↩</a></li>
  <li id="n6">Daniel Gurney, <em>Record</em> (1848), Norfolk pedigree p. 286: "he lived during the civil wars in the reign of Stephen." Liber Niger Scaccarii reference as above. <a class="citation-back" href="#ref-6">↩</a></li>
  <li id="n7">Daniel Gurney, <em>Record</em> (1848), p. 278: William I "held of the King in capite the lordship of Montigny-sur-Andelle, in the Pays de Bray ... William de Gournay having held this Norman manor in capite, forms, therefore, an incontestable proof of his descent in blood from the Barons of Gournay." <a class="citation-back" href="#ref-7">↩</a></li>
  <li id="n8">Daniel Gurney, <em>Record</em> (1848), pp. 277–278 and pedigree p. 286. <a class="citation-back" href="#ref-8">↩</a></li>
</ol>
</section>

  </div>

  <aside class="factsheet-side">

{% if factsheet.heroImage %}
<figure class="fact-panel fact-hero">
  <img src="{{ factsheet.heroImage }}" alt="{{ factsheet.heroAlt or ('Historical image associated with ' + factsheet.personName) }}">
  <figcaption>{{ factsheet.heroCaption }}{% if factsheet.heroCredit %} {{ factsheet.heroCredit }}{% endif %}</figcaption>
</figure>
{% endif %}

<div class="fact-panel">
  <h2>Related Links</h2>
  <div class="fact-buttons">
    <a href="/maps-and-lists/ancestor-table.html">Ancestor Table</a>
    <a href="https://www.british-history.ac.uk/topographical-hist-norfolk/vol8/pp452-459">Blomefield: Harpley</a>
    <a href="https://en.wikipedia.org/wiki/The_Anarchy">The Anarchy (Wikipedia)</a>
  </div>
</div>

<div class="fact-panel">
  <h2>Timeline</h2>
  <table class="fact-timeline-table">
    <tbody>
      <tr><th>Year</th><th>Event</th></tr>
      <tr><td>c. 1108</td><td>Born, youngest son of Gerard de Gournay and Edith de Warenne.</td></tr>
      <tr><td>Before 1104</td><td>Father Gerard dies in Palestine; Walter and brothers divide the English estates.</td></tr>
      <tr><td>1135–1154</td><td>Holds manors in Norfolk and Suffolk during "The Anarchy" of Stephen's reign.</td></tr>
      <tr><td>c. 1150</td><td>Son William I (G30) born.</td></tr>
      <tr><td>c. 1154</td><td>Approximate end of active period. Death date unknown.</td></tr>
    </tbody>
  </table>
</div>

  </aside>
</div>

---

## Research Appendix

### Lineage Status
**Confirmed.** Walter is named in the Liber Niger Scaccarii (vol. i, p. 298) as a landholder under Manasser de Dampmartin in Suffolk during Stephen's reign — a contemporary royal administrative record. His identification as youngest son of Gerard de Gournay is described by DG as "probable" (not certain), but is strongly supported by the parage tenure his son William I held at Montigny-sur-Andelle, which was only available to blood relatives of the senior Gournay lords.

### Note on "probably son of Gerard"
Daniel Gurney, <em>Record</em> (1848) p. 286 uses the word "probably" in the pedigree header for Walter. This reflects the absence of a document explicitly stating the father-son relationship between Gerard and Walter. The Montigny-sur-Andelle parage evidence is the strongest corroboration. This should be borne in mind: Walter is not confirmed by a direct paternity document, but the evidence for his Gournay blood descent is strong enough to classify as Confirmed rather than Probable.

### Sources Consulted
- Daniel Gurney, <em>Record</em> (1848), pp. 277–278 and pedigree p. 286.
- Liber Niger Scaccarii (cited by DG); Hearne ed. 1774.
- Ancestors_v3.json; Gurney_Research_KnowledgeBase_1.md.

### Negative Results
- No wife named in any source.
- No death date or burial site recorded.
- No surviving deed issued by Walter himself found in project sources.

### Open Questions
1. The Liber Niger Scaccarii entry (vol. i, p. 298) — the full text could be checked to confirm exactly how Walter is designated and what the Manasser de Dampmartin tenure entailed.
2. Are there any Norfolk fines or assizes from Stephen's reign that name Walter de Gournay?
3. The fiefs of Runhall and Swathings: DG notes these came to the junior branch probably through the forfeiture of the Le Bourguignon family when Normandy was lost in 1204. The timing of that transfer relative to Walter's active years could clarify when exactly he acquired them.

### Hero Image Note
Harpley Church (St. Lawrence) is the most appropriate visual for this batch — the manor Walter's descendants would hold for ~150 years. A Geograph photograph is available under CC BY-SA. Caption must note that Walter himself predates the Harpley manor acquisition (which came through Matthew's marriage c. 1183), but the church represents the family's primary Norfolk home.
