---
layout: layouts/base.njk
permalink: /fact-sheets/g14-francis-gurney-fact-sheet.html
title: Francis Gurney Fact Sheet
pageHeading: Francis Gurney (1581–1646/7)
subtitle: "Ancestor fact sheet for G14 in the direct Gurney line. Merchant Taylor of London and probable father of John Gurney-1 of Massachusetts. Published 2 April 2026."
description: "Compact fact sheet for Francis Gurney, Merchant Taylor of London and probable father of John Gurney-1 of Massachusetts."
bodyClass: bio-page factsheet-page
activeNav: factsheets
updated: 2 April 2026
factsheet:
  gen: G14
  slug: g14-francis-gurney-fact-sheet
  personName: Francis Gurney
  heroImage: /media/factsheets/g14-francis-gurney-hero.png
  heroAlt: Historical drawing of St Benet Fink, London
  heroCaption: St Benet Fink, the London parish most closely associated with Francis Gurney's later family.
  heroCredit: Historical drawing, public domain.
---

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "ProfilePage",
  "name": "{{ factsheet.personName }} — Fact Sheet",
  "description": "{{ description }}",
  "mainEntity": {
    "@type": "Person",
    "name": "{{ factsheet.personName }}",
    "givenName": "Francis",
    "familyName": "Gurney",
    "alternateName": ["Francis Gurnay", "Francis Gournay", "Francis Gurnie", "Francis Gurny"],
    "birthDate": "1581-09-13",
    "deathDate": "1647-01-09",
    "birthPlace": { "@type": "Place", "name": "West Barsham Hall, Norfolk, England" },
    "deathPlace": { "@type": "Place", "name": "London, England" },
    "jobTitle": "Merchant Taylor",
    "description": "Merchant Taylor of London, financial agent to the Lestrange family, and probable father of John Gurney-1 of Massachusetts."
  }
}
</script>

<div class="factsheet-top">
  <div class="factsheet-main">

<section class="fact-section fact-section-vitals" id="vital-records">
<div class="facts-vitals-grid">
  <div class="fact-item">
    <div class="fact-label">Born</div>
    <div class="fact-value">13 September 1581, West Barsham Hall, Norfolk, England. Twin with Anthony; sixth son of Henry de Gournay and Ellen Blennerhassett. <sup class="fn"><a href="#n1" id="ref-1">1</a></sup></div>
  </div>
  <div class="fact-item">
    <div class="fact-label">Died</div>
    <div class="fact-value">9 January 1646/7, London, England. Buried at St Botolph Bishopsgate; Boyd's index misread the year as 1641, corrected March 2026. <sup class="fn"><a href="#n2" id="ref-2">2</a></sup></div>
  </div>
  <div class="fact-item">
    <div class="fact-label">Occupation / Education / Religion</div>
    <div class="fact-value">Merchant Taylor. Admitted to the freedom of the Merchant Taylors' Company on 16 June 1606; later acted as a financial agent — described as "a sort of agent, or banker" — for the Lestrange family of Hunstanton Hall from 1612 to 1636. Apprenticed to Henry Tryme and assigned to William Smooth. The Lestrange appointment was almost certainly underwritten by kinship: Francis's great-great-grandmother Anne Heydon (wife of William Gurney V, G18) was sister of Amy Heydon, who married Sir Roger Lestrange of Hunstanton — making Francis a fourth cousin of the Lestranges he served, and explaining why a London Merchant Taylor would be entrusted with the financial business of a north-Norfolk gentry household. The Lestranges habitually used kin for sensitive financial matters, as the published Hunstanton household and privy purse accounts (1519–1578) make clear. Church of England, with documented Puritan family connections. <sup class="fn"><a href="#n4" id="ref-4">4</a></sup></div>
  </div>
  <div class="fact-item">
    <div class="fact-label">Buried</div>
    <div class="fact-value">9 January 1646/7, St Botolph Bishopsgate, London. <sup class="fn"><a href="#n3" id="ref-3">3</a></sup></div>
  </div>
  <div class="fact-item fact-item-span-2">
    <div class="fact-label">Marriage(s)</div>
    <div class="fact-value">
      <div class="stacked-records">
        <div><strong>Margaret Rybett</strong> — married 23 September 1611 at St Martin at Palace, Norwich, Norfolk. Norfolk/Suffolk gentry; the Rybett/Ryvett family of Fritton, Rishangles, and Stowmarket. Mirabella Ryvett married Sir John Heydon of Baconsthorpe, connecting the family to the Gurneys. Margaret probably died c. 1616–1617; her burial has not yet been located. <sup class="fn"><a href="#n5" id="ref-5">5</a></sup></div>
        <div><strong>Anne Browning</strong> — married c. late 1617, probably at Norwich though the record has not yet been located. Daughter of William Browning, merchant of Norwich and later Maldon, Essex. <sup class="fn"><a href="#n6" id="ref-6">6</a></sup></div>
      </div>
    </div>
  </div>
</div>
</section>

<section class="fact-panel fact-panel-highlights" id="highlights">
<h2 class="unnumbered">Highlights</h2>

<ul>
  <li><strong>Lestrange financial agent — and a fourth cousin of the family he served.</strong> Francis acted as financial agent (described as "a sort of agent, or banker") to the Lestranges of Hunstanton Hall from 1612 to 1636. The appointment was kinship-based: his great-great-grandmother Anne Heydon (G18's wife) was sister of Amy Heydon, who had married Sir Roger Lestrange of Hunstanton in the late 15th century. Francis was therefore a fourth cousin of the Lestranges he served — and Norfolk gentry strongly preferred to do their financial business with kin. The Lestrange Hunstanton household and privy purse accounts (published by Daniel Gurney in <em>Archaeologia</em> vol. 25 in 1832, covering 1519–1578) document a generation earlier the same family using Francis's great-grandfather Anthony Gurney G17 as a regular dinner companion. The kinship link survived through 90 years and three generations to bring Francis the Hunstanton agency. <sup class="fn"><a href="#nL" id="ref-nL">L</a></sup></li>
  <li><strong>First marriage identified in the original register in March 2026.</strong> The marriage of Francis Gurney and Margaret Rybett at St Martin at Palace, Norwich, on 23 September 1611 closes the long unexplained gap between Francis's freedom in 1606 and his first London child in 1619. <sup class="fn"><a href="#n7" id="ref-7">7</a></sup></li>
  <li><strong>Probable father of John Gurney-1 of Massachusetts.</strong> The East Dereham baptism long indexed as “John son of Nicholas Gorne” now appears, after structured paleographic review, to favor a reading of Francis Gurnie. If upheld professionally, it would connect the Massachusetts emigrant to the Norfolk gentry line. <sup class="fn"><a href="#n8" id="ref-8">8</a></sup></li>
  <li><strong>Financial collapse likely shaped the family's future.</strong> Francis liquidated all Norfolk and Suffolk lands in 1634. That sale, together with the failed King's Lynn enterprise, helps explain why an older son such as John would have seen little inheritance ahead in England. <sup class="fn"><a href="#n9" id="ref-9">9</a></sup></li>
  <li><strong>Positioned inside strong Puritan-era networks.</strong> His Broad Street Ward parish sat beside Coleman Street Ward, one of the strongest Puritan zones in London, while his brother Edmund was an openly militant Puritan clergyman. <sup class="fn"><a href="#n10" id="ref-10">10</a></sup></li>
</ul>
</section>


<section class="fact-section" id="children">
<h2 class="unnumbered">Children</h2>

<table class="facts-children">
  <thead>
    <tr>
      <th>Name</th>
      <th>Dates</th>
      <th>Mother</th>
      <th>Notes</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>John Gurney</td><td>c. 1609/10</td><td>Margaret Rybett</td><td>Probable — Entry E, East Dereham register; probable G13 in direct line. <sup class="fn"><a href="#n11" id="ref-11">11</a></sup></td></tr>
    <tr><td>Edward Gurney</td><td>c. 1611/12</td><td>Margaret Rybett</td><td>Baptized East Dereham (Entry A). <sup class="fn"><a href="#n12" id="ref-12">12</a></sup></td></tr>
    <tr><td>Ann Gurney</td><td>c. 1612–16? (probable)</td><td>Margaret Rybett</td><td>Probable daughter. Married John Gilman at Hingham, Norfolk, 1 October 1626. <sup class="fn"><a href="#n13" id="ref-13">13</a></sup></td></tr>
    <tr><td>Agnes Gurney</td><td>c. 1614</td><td>Margaret Rybett</td><td>Baptized East Dereham (Entry C). <sup class="fn"><a href="#n14" id="ref-14">14</a></sup></td></tr>
    <tr><td>Marye Gurney (first)</td><td>c. 1614–15</td><td>Margaret Rybett</td><td>Entry B, East Dereham. May have died young; name reused in 1618. <sup class="fn"><a href="#n15" id="ref-15">15</a></sup></td></tr>
    <tr><td>Marye Gurney (second)</td><td>25 May 1618</td><td>Anne Browning</td><td>Baptized East Dereham (Entry D); probably first child with Anne. <sup class="fn"><a href="#n16" id="ref-16">16</a></sup></td></tr>
    <tr><td>Dorothy Gurney</td><td>2 March 1619</td><td>Anne Browning</td><td>First London child, baptized St Benet Fink. <sup class="fn"><a href="#n17" id="ref-17">17</a></sup></td></tr>
    <tr><td>Roger Gurney</td><td>27 December 1621</td><td>Anne Browning</td><td>Baptized St Benet Fink. Listed as eldest son in the 1633 visitation. <sup class="fn"><a href="#n18" id="ref-18">18</a></sup></td></tr>
    <tr><td>Anne Gurney</td><td>c. 1624</td><td>Anne Browning</td><td>Baptized St Benet Fink. Died in infancy and was buried in 1625. <sup class="fn"><a href="#n19" id="ref-19">19</a></sup></td></tr>
    <tr><td>Francis Gurney</td><td>13 December 1625</td><td>Anne Browning</td><td>Baptized St Benet Fink; probably died young. <sup class="fn"><a href="#n20" id="ref-20">20</a></sup></td></tr>
    <tr><td>Anne Gurney (second)</td><td>14 September 1628</td><td>Anne Browning</td><td>Baptized St Benet Fink. <sup class="fn"><a href="#n21" id="ref-21">21</a></sup></td></tr>
    <tr><td>Margaret Gurney</td><td>10 September 1630</td><td>Anne Browning</td><td>Baptized St Benet Fink. <sup class="fn"><a href="#n22" id="ref-22">22</a></sup></td></tr>
    <tr><td>Deborah Gurney</td><td>21 August 1632</td><td>Anne Browning</td><td>Baptized St Benet Fink. <sup class="fn"><a href="#n23" id="ref-23">23</a></sup></td></tr>
    <tr><td>Elizabeth Gurney</td><td>10 February 1634/5</td><td>Anne Browning</td><td>Baptized St Benet Fink. <sup class="fn"><a href="#n24" id="ref-24">24</a></sup></td></tr>
    <tr><td>Mary Gurney</td><td>19 December 1637</td><td>Anne Browning</td><td>Youngest currently identified child baptized St Benet Fink. <sup class="fn"><a href="#n25" id="ref-25">25</a></sup></td></tr>
  </tbody>
</table>
</section>

<section class="fact-section fact-narrative" id="narrative">
<h2 class="unnumbered">Narrative</h2>

Francis Gurney was born into the Norfolk gentry but made his career in trade rather than landholding. As a younger son of Henry de Gournay of West Barsham and Great Ellingham, he followed the standard path of apprenticeship and London company membership, entering the Merchant Taylors' Company and building a commercial life tied to both Norwich and the City of London. Daniel Gurney's nineteenth-century family history, reinforced by company and parish records, places him in the world of merchant capital, regional agency work, and urban parish networks rather than on a surviving landed estate.

His adult life helps explain how a cadet branch of an old Norfolk family could produce descendants who later crossed the Atlantic. Francis married first Margaret Rybett in 1611, linking himself to established Norfolk and Suffolk gentry. The East Dereham baptisms then place the family back in Norfolk through the 1610s before the London baptisms at St Benet Fink begin in 1619. By the 1620s and 1630s, Francis appears to have been financially strained: a failed King's Lynn textile venture, continuing debts, and the 1634 sale of all his Norfolk and Suffolk lands suggest that the family's prospects had narrowed sharply.

That contraction is central to the current argument about John Gurney-1 of Massachusetts. If the East Dereham baptism traditionally indexed as a son of Nicholas Gorne is instead a son of Francis Gurnie, then Francis becomes the strongest presently identified candidate for John's father. In that reading, the likely future of an older son in a financially weakened merchant-gentry household helps make emigration to New England materially more understandable.
</section>

<section class="fact-section" id="citations">
<h2 class="unnumbered">Citations</h2>

<ol class="citation-list">
  <li id="n1">Daniel Gurney, <em>Supplement to the Record of the House of Gournay</em> (King's Lynn: Thew & Son, 1858), p. 524 ff. (the chapter on the descent of Henry Gurney's children). Note: the Supplement (1858) is the second part of Daniel Gurney's two-part private family history; the first part is <em>The Record of the House of Gournay</em> (London: privately printed for the author by John Bowyer Nichols and Son, 1848). Both volumes are digitised on the Internet Archive. <a class="citation-back" href="#ref-1">↩</a></li>
  <li id="n2">FreeREG, St Botolph Bishopsgate burial entry for Francis Gurney; Boyd's published index misread the year, corrected March 2026 by review of the register context. <a class="citation-back" href="#ref-2">↩</a></li>
  <li id="n3">St Botolph Bishopsgate parish burial entry, 9 January 1646/7. <a class="citation-back" href="#ref-3">↩</a></li>
  <li id="n4">Merchant Taylors' Company freedom admission, 16 June 1606; Daniel Gurney, <em>Supplement to the Record of the House of Gournay</em> (King's Lynn: Thew & Son, 1858), pp. 524–526; Hunstanton Hall / Lestrange references summarized in Daniel Gurney's <em>Supplement</em>. The Lestrange-Heydon kinship that almost certainly underwrote the appointment is documented at the G18 William Gurney V fact sheet. The Lestrange of Hunstanton accounts themselves are published as Daniel Gurney, "Extracts from the Household and Privy Purse Accounts of the Lestranges of Hunstanton, from A.D. 1519 to A.D. 1578," <em>Archaeologia</em> vol. 25 (London: Society of Antiquaries, 1832), pp. 411–569. <a class="citation-back" href="#ref-4">↩</a></li>
  <li id="nL">Lestrange-Heydon kinship: see the G18 William Gurney V fact sheet for full documentation. Anne Heydon (G18's wife, Francis's great-great-grandmother) was a daughter of Sir Henry Heydon of Baconsthorpe Castle by Anne Boleyn the elder of Blickling. Per the WikiTree profile for Sir Henry Heydon citing his Prerogative Court of Canterbury will of 1503/4, Anne Heydon's siblings included Amy Heydon, who married Sir Roger Lestrange of Hunstanton — making Francis Gurney G14 a fourth cousin of the Lestranges he served. The Lestrange Hunstanton household and privy purse accounts published by Daniel Gurney in <em>Archaeologia</em> vol. 25 (1832) document Francis's great-grandfather Anthony Gurney G17 dining at Hunstanton Hall in the 1520s–1550s as "Anthony Gurney, Esq. of West Barsham and Great Ellingham" (p. 528 note i) — i.e., the Norfolk Gurney–Lestrange kinship was actively maintained for at least three generations before Francis's appointment as Lestrange agent in 1612. <a class="citation-back" href="#ref-nL">↩</a></li>
  <li id="n5">Norfolk Record Office, St Martin at Palace, Norwich, marriage register, 23 September 1611, Francis Gurney and Margaret Rybett; supporting Rybett/Ryvett family context from Norfolk and Suffolk gentry sources. <a class="citation-back" href="#ref-5">↩</a></li>
  <li id="n6">Daniel Gurney, <em>Supplement</em> (1858); Browning family identification from Norwich and Maldon records summarized in the Francis research file. <a class="citation-back" href="#ref-6">↩</a></li>
  <li id="n7">March 2026 East Dereham / Norwich register review establishing the St Martin at Palace marriage as the best-supported first marriage for Francis. <a class="citation-back" href="#ref-7">↩</a></li>
  <li id="n8">John Gurney Case File and East Dereham AI Procedure; paleographic review of the East Dereham baptism line traditionally indexed as Nicholas Gorne. <a class="citation-back" href="#ref-8">↩</a></li>
  <li id="n9">Daniel Gurney, <em>Supplement</em> (1858); 1634 land-sale summary and failed King's Lynn textile venture references. <a class="citation-back" href="#ref-9">↩</a></li>
  <li id="n10">Broad Street Ward / Coleman Street Ward Puritan context and Edmund Gurney's Puritan ministry as summarized in the John Gurney Case File bibliography. <a class="citation-back" href="#ref-10">↩</a></li>
  <li id="n11">East Dereham register Entry E; John Gurney Case File section on the candidate baptism. <a class="citation-back" href="#ref-11">↩</a></li>
  <li id="n12">East Dereham register Entry A. <a class="citation-back" href="#ref-12">↩</a></li>
  <li id="n13">Hingham, Norfolk parish marriage entry for Ann Gurney and John Gilman, 1626. <a class="citation-back" href="#ref-13">↩</a></li>
  <li id="n14">East Dereham register Entry C. <a class="citation-back" href="#ref-14">↩</a></li>
  <li id="n15">East Dereham register Entry B. <a class="citation-back" href="#ref-15">↩</a></li>
  <li id="n16">East Dereham register Entry D. <a class="citation-back" href="#ref-16">↩</a></li>
  <li id="n17">St Benet Fink baptism register, 2 March 1619, Dorothy daughter of Francis Gurney. <a class="citation-back" href="#ref-17">↩</a></li>
  <li id="n18">St Benet Fink baptism register, 27 December 1621, Roger son of Francis Gurney; Heralds' Visitation of London, 1633. <a class="citation-back" href="#ref-18">↩</a></li>
  <li id="n19">St Benet Fink baptism and burial sequence for Anne Gurney. <a class="citation-back" href="#ref-19">↩</a></li>
  <li id="n20">St Benet Fink baptism register, 13 December 1625, Francis son of Francis Gurney. <a class="citation-back" href="#ref-20">↩</a></li>
  <li id="n21">St Benet Fink baptism register, 14 September 1628, Anne daughter of Francis Gurney. <a class="citation-back" href="#ref-21">↩</a></li>
  <li id="n22">St Benet Fink baptism register, 10 September 1630, Margaret daughter of Francis Gurney. <a class="citation-back" href="#ref-22">↩</a></li>
  <li id="n23">St Benet Fink baptism register, 21 August 1632, Deborah daughter of Francis Gurney. <a class="citation-back" href="#ref-23">↩</a></li>
  <li id="n24">St Benet Fink baptism register, 10 February 1634/5, Elizabeth daughter of Francis Gurney. <a class="citation-back" href="#ref-24">↩</a></li>
  <li id="n25">St Benet Fink baptism register, 19 December 1637, Mary daughter of Francis Gurney. <a class="citation-back" href="#ref-25">↩</a></li>
</ol>
</section>

  </div>

  <aside class="factsheet-side">

{% if factsheet.heroImage %}
<figure class="fact-panel fact-hero">
  <img src="{{ factsheet.heroImage }}" alt="{{ factsheet.heroAlt or ('Historical image associated with ' + factsheet.personName) }}">
  <figcaption>{{ factsheet.heroCaption }} {{ factsheet.heroCredit }}</figcaption>
</figure>
{% endif %}

<div class="fact-panel">
  <h2>Related Links</h2>
  <div class="fact-buttons">
    <a href="/key-research/john-gurney-case-file.html">Case File</a>
    <a href="/key-research/east-dereham-ai-assistant-procedure.html">AI Procedure</a>
    <a href="https://en.wikipedia.org/wiki/St_Benet_Fink">St Benet Fink</a>
    <a href="https://historicengland.org.uk/listing/the-list/list-entry/1298188">St James's Chapel</a>
    <a href="http://www.pennyghael.org.uk/Gurney.pdf">Pease Genealogy</a>
  </div>
</div>

<div class="fact-panel">
  <h2>Timeline</h2>
  <table class="fact-timeline-table">
    <tbody>
      <tr><th>Year</th><th>Event</th></tr>
      <tr><td>1581</td><td>Born at West Barsham Hall in north Norfolk; twin with Anthony.</td></tr>
      <tr><td>c. 1597</td><td>Apprenticed in London to Henry Tryme, Merchant Taylor.</td></tr>
      <tr><td>1606</td><td>Admitted to the freedom of the Merchant Taylors' Company on 16 June.</td></tr>
      <tr><td>1611</td><td>Married Margaret Rybett at St Martin at Palace, Norwich.</td></tr>
      <tr><td>1612</td><td>First documented Lestrange agency payment.</td></tr>
      <tr><td>1609–1618</td><td>Children were baptized at East Dereham, linking Francis to Norfolk through the 1610s.</td></tr>
      <tr><td>1619</td><td>Family established at St Benet Fink in London.</td></tr>
      <tr><td>c. 1622–25</td><td>King's Lynn textile venture failed.</td></tr>
      <tr><td>1633</td><td>Attested pedigree at the Heralds' Visitation of London.</td></tr>
      <tr><td>1634</td><td>Sold all Norfolk and Suffolk lands for £1,000.</td></tr>
      <tr><td>1636</td><td>Last documented Lestrange payment.</td></tr>
      <tr><td>1646/7</td><td>Died 9 January and was buried at St Botolph Bishopsgate.</td></tr>
    </tbody>
  </table>
</div>



  </aside>
</div>
